저를 wrtieme3.txt로 보내주세요.
